# VANTA AI starter

This starter contains a website and server-side fal.ai queue integration.

IMPORTANT: This is not yet a complete commercial service. It does not include user accounts, database-backed three-free-generation limits, payments, moderation, or production monitoring.

Before deployment:
1. Choose a video model on fal.ai and confirm its exact input fields and output format.
2. Add `FAL_KEY` as a Vercel Environment Variable. Never put the secret in browser code or GitHub.
3. Add `FAL_MODEL` with the exact model ID from fal.ai (for example `owner/model-name`). Choose a model that accepts a `prompt` field.
4. Deploy and test. The generic prompt payload/output parsing may need model-specific adjustment.

The site calls `/api/generate` and `/api/status`; the fal secret stays server-side. The integration follows fal.ai Queue API documentation.
