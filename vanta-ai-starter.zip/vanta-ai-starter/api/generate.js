export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const key = process.env.FAL_KEY, model = process.env.FAL_MODEL;
  if (!key || !model) return res.status(500).json({ error: "Server setup is incomplete. Add FAL_KEY and FAL_MODEL in Vercel Environment Variables." });
  const { prompt, language, aspect_ratio } = req.body || {};
  if (typeof prompt !== "string" || !prompt.trim() || prompt.length > 2000) return res.status(400).json({ error: "Enter a prompt of up to 2,000 characters." });
  try {
    const response = await fetch(`https://queue.fal.run/${model}`, { method: "POST", headers: { "Authorization": `Key ${key}`, "Content-Type": "application/json" }, body: JSON.stringify({ prompt: `${prompt.trim()}\nSpoken language: ${language || "Turkish"}. Aspect ratio requested: ${aspect_ratio || "9:16"}.` }) });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.detail || data.error || "fal.ai rejected the request." });
    return res.status(200).json({ request_id: data.request_id, status_url: data.status_url, response_url: data.response_url });
  } catch { return res.status(502).json({ error: "Could not reach the video generation service." }); }
}