export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const key = process.env.FAL_KEY, { status_url, response_url } = req.body || {};
  const safe = value => typeof value === "string" && value.startsWith("https://queue.fal.run/");
  if (!key || !safe(status_url) || !safe(response_url)) return res.status(400).json({ error: "Invalid status request." });
  try {
    const s = await fetch(status_url, { headers: { "Authorization": `Key ${key}` } }), status = await s.json();
    if (!s.ok) return res.status(s.status).json({ error: status.detail || "Status check failed." });
    if (status.status !== "COMPLETED") return res.status(200).json({ status: status.status });
    const r = await fetch(response_url, { headers: { "Authorization": `Key ${key}` } }), result = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: result.detail || "Could not retrieve result." });
    const video_url = result.video?.url || result.output?.video?.url || result.videos?.[0]?.url || null;
    return res.status(200).json({ status: "COMPLETED", error: status.error || null, video_url });
  } catch { return res.status(502).json({ error: "Could not reach the video generation service." }); }
}